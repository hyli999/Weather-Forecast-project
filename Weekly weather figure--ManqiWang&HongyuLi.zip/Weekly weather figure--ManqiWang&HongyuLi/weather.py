#!/usr/bin/env python

# The project requires the mako template engine (https://www.makotemplates.org/)
# Install mako by:
# pip install mako

import os
import platform
import sys
import datetime
import random
from mako.template import Template


TMP_FILENAME = 'tmp.html'
weather_icons = ['sunny', 'rainy', 'cloudy']


def format_date_from_today(day_from_today = 0):
    d = datetime.datetime.now() + datetime.timedelta(days=day_from_today)
    return str(d.year) + '-' + str(d.month) + '-' + str(d.day)


def format_weekday_from_today(day_from_today = 0):
    d = datetime.datetime.now() + datetime.timedelta(days=day_from_today)
    return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d.weekday()]


class Weather:
    def __init__(self, date, weekday, temperature_lo, temperature_hi, icon_label):
        self.date = date
        self.weekday = weekday
        self.temperature_lo = temperature_lo
        self.temperature_hi = temperature_hi
        self.icon_label = icon_label


    def get_weekday(self):
        return self.weekday


    def get_date(self):
        return self.date


    def get_icon_label(self):
        return self.icon_label


    def get_temperature_lo(self):
        return self.temperature_lo


    def get_temperature_hi(self):
        return self.temperature_hi


def render(city, weathers):
    template = Template(filename='template.html')
    data = template.render(city=city, weathers=weathers)
    f = open(TMP_FILENAME, 'w')
    f.write(data)
    f.close()
    print(TMP_FILENAME + ' written')
    if os.name == 'posix':
        if platform.system() == 'Linux':
            os.system('google-chrome ' + TMP_FILENAME)
        elif platform.system() == 'Darwin':
            os.system('open ' + TMP_FILENAME)


def enter_info():
    # Introduction
    print('Hi, I am a weather forecaster.')
    print('I would like to ask you some questions and give you a weekly weather figure')
    print('Which city do you live in?')
    # Get information from user
    # City
    city = input('Enter the name of city (e.g. Hongkong): ')
    # Weather in the coming 7 days
    print('Please enter the weather in format (High Temperature, Low Temperature, Icon)  (e.g. 27,21,sunny)')
    weathers = []
    for day_from_today in range(0, 7):
        date = format_date_from_today(day_from_today)
        weekday = format_weekday_from_today(day_from_today)
        print('What is the weather of ' + date)
        while True:
            info = input('Enter the weather: ')
            parts = info.strip().split(',')
            if len(parts) == 3 and \
                    parts[2] in weather_icons:
                weathers.append(Weather(date, weekday, parts[0], parts[1], parts[2]))
                break
            else:
                print('Invalid format')
    render(city, weathers)


def random_temp_lo():
    return random.randint(10, 20)


def random_temp_hi():
    return random.randint(20, 30)


def random_icon():
    return random.choice(weather_icons)


def sample_info():
    city = 'Hongkong'
    weathers = []
    for i in range(0, 7):
        date = format_date_from_today(i)
        weekday = format_weekday_from_today(i)
        weathers.append(Weather(date, weekday, random_temp_lo(), random_temp_hi(), random_icon()))
    render(city, weathers)


def main():
    if len(sys.argv) == 2 and sys.argv[1] == 'sample':
        sample_info()
    else:
        enter_info()


if __name__ == '__main__':
    main()
